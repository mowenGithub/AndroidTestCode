var HTLNoGxPrepayRoomPicassoCell_B;
(function(HTLNoGxPrepayRoomPicassoCell_B) {
	function layout(args, data) {
		cellWidth = args.width;
        scale = cellWidth / 375.0;
        cellHeight = 138 * scale;

        // 壳
        var container = View.viewWithFrame(0, 0, cellWidth, cellHeight);
        container.backgroundColor = "#2876FF";

		var titleViewFirstLine = TextView.viewWithFrame(0, 25*scale, 0, 0);
		titleViewFirstLine.text = "－ 注意 HTLNoGxPrepayRoomPicassoCell_B TEST 注意 －";
		titleViewFirstLine.textSize = 12*scale;
		titleViewFirstLine.numberOfLines = 1;
		titleViewFirstLine.lineBreakMode = 4;
		titleViewFirstLine.textColor = "#bebebe";
        titleViewFirstLine.sizeToFit();
        titleViewFirstLine.centerX = container.centerX;
		container.addSubView(titleViewFirstLine);

        var imageView = ImageView.viewWithFrame(0, titleViewFirstLine.bottom + 15*scale, 232*scale, 12*scale);
        imageView.imageUrl = "http://p1.meituan.net/codeman/7e31b01cfd63b81566037a4fa4a1303a9693.png";
        imageView.contentMode = 0;
        imageView.centerX = container.centerX;
        container.addSubView(imageView);


				        var titleViewSecondLine = TextView.viewWithFrame(0, titleViewFirstLine.bottom + 15*scale, 0, 0);
				        titleViewSecondLine.text = "入住免押金 / 离店免查房";
				        titleViewSecondLine.textSize = 11*scale;
				        titleViewSecondLine.numberOfLines = 1;
				        titleViewSecondLine.lineBreakMode = 4;
				        titleViewSecondLine.textColor = "#bebebe";
				        titleViewSecondLine.sizeToFit();
				        titleViewSecondLine.centerX = container.centerX;
				        container.addSubView(titleViewSecondLine);
								
        var titleViewThirdLine = TextView.viewWithFrame(0, titleViewSecondLine.bottom + 8*scale, 0, 0);
        titleViewThirdLine.text = "下单后瞬间确认 / 可在线预约发票";
        titleViewThirdLine.textSize = 11*scale;
        titleViewThirdLine.numberOfLines = 1;
        titleViewThirdLine.lineBreakMode = 4;
        titleViewThirdLine.textColor = "#bebebe";
        titleViewThirdLine.sizeToFit();
        titleViewThirdLine.centerX = container.centerX;
        container.addSubView(titleViewThirdLine);

		return container;
	}
	HTLNoGxPrepayRoomPicassoCell_B.layout = layout;
})(HTLNoGxPrepayRoomPicassoCell_B || (HTLNoGxPrepayRoomPicassoCell_B = {}));
