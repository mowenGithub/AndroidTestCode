var NonLocalRecommendCell;
(function(NonLocalRecommendCell) {
	function isPriceAvailable(data) {
		return (data.priceType == 1 || data.priceType == 0) && data.lowestPrice >= 0;
	}

	function getPriceSurfixString(data) {
		if (data.dayRoomSpan > 1) {
			return "/" + data.dayRoomSpan + "晚";
		} else {
			return "起";
		}
	}

	function getGreenColor() {
		return "#06C1AE";
	}

	function getGrayColor() {
		return "#999999";
	}

	function getOrangeColor() {
		return "#FF9900";
	}

	function layout(args, data) {
		width = args.width;

		var paddingTop = 14;
		var paddingLeft = 12;
		var imageWidth = 78;
		var titlePaddingLeft = 8;

		var container = View.viewWithFrame(0, 0, width, paddingTop * 2 + imageWidth + 8 + 30);
		container.backgroundColor = "#EC5330";

		var imageView = ImageView.viewWithFrame(paddingLeft, paddingTop, imageWidth, imageWidth);
		imageView.imageUrl = data.frontImg;
		imageView.contentMode = 2;
		container.addSubView(imageView);

		// 右边的总长度
		var rightWidth = width - paddingLeft * 2 - imageWidth - titlePaddingLeft;
		//title
		var titleView = TextView.viewWithFrame(imageView.right + titlePaddingLeft, imageView.top, 0, 0);
		titleView.text = data.name;
		titleView.textSize = 17;
		titleView.sizeToFit();
		titleView.numberOfLines = 1;
		titleView.lineBreakMode = 4;
		titleView.textColor = "#EC5330";
		titleView.width = rightWidth;
		container.addSubView(titleView);

		// 第二行，包括评分，消费人数，星级
		var top = titleView.bottom + 6;
		var avgScoreView = TextView.viewWithFrame(titleView.left, top, 0, 0);
		avgScoreView.textSize = 12;
		avgScoreView.textColor = getOrangeColor();
		avgScoreView.text = data.scoreIntro ? data.scoreIntro : "";
		avgScoreView.sizeToFit();
		container.addSubView(avgScoreView);

		var salesView = TextView.viewWithFrame(0, top, 0, avgScoreView.height);
		salesView.textSize = 12;
		salesView.textColor = getGrayColor();
		salesView.left = avgScoreView.right + 5;
		salesView.text = data.poiSaleAndSpanTag ? data.poiSaleAndSpanTag : "暂无消费";
		salesView.sizeToFit();
		salesView.bottom = avgScoreView.bottom;
		container.addSubView(salesView);

		var top = salesView.bottom + 6;
		var pricePrefix = TextView.viewWithFrame(titleView.left, top, 0, 0);
		pricePrefix.text = "¥";
		pricePrefix.textSize = 12;
		pricePrefix.textColor = getOrangeColor();
		pricePrefix.sizeToFit();

		var priceLabel = TextView.viewWithFrame(0, top, 0, 0);
		priceLabel.text = data.lowestPrice;
		priceLabel.textSize = 21;
		priceLabel.textColor = getOrangeColor();
		container.addSubView(priceLabel);

		var priceSuffix = TextView.viewWithFrame(0, top, 0, 0);
		priceSuffix.text = getPriceSurfixString(data);
		priceSuffix.textSize = 12;
		priceSuffix.textColor = getOrangeColor();
		priceSuffix.sizeToFit();

		if (isPriceAvailable(data)) {
			container.addSubView(priceSuffix);
			container.addSubView(pricePrefix);
			priceLabel.left = pricePrefix.right;
		} else {
			priceLabel.textSize = 16;
			priceLabel.textColor = getGrayColor();
			priceLabel.text = "暂无报价";
			priceLabel.left = titleView.left;
			priceLabel.top += 4;
		}
		priceLabel.sizeToFit();
		// 模拟基线对齐
		pricePrefix.bottom = priceLabel.bottom - 4;
		priceSuffix.bottom = pricePrefix.bottom;
		priceSuffix.left = priceLabel.right;

		var addressView = TextView.viewWithFrame(0, 0, 0, 0);
		addressView.textColor = getGrayColor();
		addressView.textSize = 12;
		addressView.numberOfLines = 1;
		addressView.lineBreakMode = 4;
		addressView.text = data.posdescr ? data.posdescr : "";
		addressView.sizeToFit();
		addressView.textAlignment = 2;
		addressView.bottom = pricePrefix.bottom;
		addressView.width = rightWidth - priceSuffix.width - pricePrefix.width - priceLabel.width - 4;
		addressView.left = priceSuffix.right + 4
		container.addSubView(addressView);

		var commentView = TextView.viewWithFrame(imageView.bottom + 8, imageView.bottom + 8, width - 2 * paddingLeft, 50);
		commentView.textColor = getGrayColor();
		commentView.textSize = 12;
		commentView.numberOfLines = 2;
		commentView.width = width - 2 * paddingLeft;
		commentView.left = paddingLeft;
		commentView.text = data.tripTagNote;
		commentView.top = imageView.bottom + 8;
		commentView.sizeToFit();
		container.addSubView(commentView);

		container.height = paddingTop * 2 + imageWidth + 8 + commentView.height;
		// 底部分割线
		var bottomLine = View.viewWithFrame(0, 0, width, 0.5);
		bottomLine.bottom = container.height;
		bottomLine.backgroundColor = "#d8d8d8";
		container.addSubView(bottomLine);

		// 为了测试页面是否展示成功
		var detectFlagView = View.viewWithFrame(0, 0, 1, 1);
		detectFlagView.alpha = 0.0001;
		detectFlagView.tag = "123123123123";
		container.addSubView(detectFlagView);
		return container;
	}
	NonLocalRecommendCell.layout = layout;
})(NonLocalRecommendCell || (NonLocalRecommendCell = {}));
