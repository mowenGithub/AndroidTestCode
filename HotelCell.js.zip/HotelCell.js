var HotelCell;
(function (HotelCell) {
    function createTagLabel(left, top, text, textColor, isFullRoom) {
        var tagView = TextView.viewWithFrame(3, 2, 0, 0)
        tagView.text = text
        tagView.textColor = isFullRoom ? "#CCCCCC": textColor
        tagView.textSize = 10
        tagView.sizeToFit()

        var container = View.viewWithFrame(left, top, tagView.width + 6, tagView.height + 4)
        container.backgroundColor = "#FFFFFFFF";
        container.borderWidth = 0.5
        container.borderColor = isFullRoom ? "#CCCCCC": textColor
        container.cornerRadius = 1
        container.addSubView(tagView)
        return container
    }

    function getFodderInfoStr(data, boothId){
        if (data.fodderInfo != null && data.fodderInfo.length > 0) {
            for (i=0; i<data.fodderInfo.length; i++) {
                if (data.fodderInfo[i].boothId == boothId) {
                    if (data.fodderInfo[i] != null && data.fodderInfo[i].url != null && data.fodderInfo[i].url.length > 0){
                        return data.fodderInfo[i].url
                    }
                }
            }
        }
        return null;
    }

    function hasLowestPrice(priceType, lowestPrice) {
        return (priceType == 0 || priceType == 1) && lowestPrice >= 0;
    }

    function getGreenColor(isFullRoom){
        return isFullRoom ? "#CCCCCC" : "#06C1AE"
    }

    function getGrayColor(isFullRoom){
        return isFullRoom ? "#CCCCCC" : "#999999"
    }

    function getOrangeColor(isFullRoom){
        return isFullRoom ? "#CCCCCC" : "#FF9900"
    }

    function layout(args, data) {
        if(typeof(args) === "number"){
            width = args
        } else {
            width = args.width
        }
        var isFullRoom = data.hotelAppointmentExtType == 0
        var paddingTop = 7
        var paddingLeft = 12
        var imageWidth = 108
        var titlePaddingLeft = 8
        if(typeof(data.priceType)=="undefined") {
            data.priceType = 0
        }

        var container = View.viewWithFrame(0, 0, width, paddingTop*2 + imageWidth)
        container.backgroundColor = "#ffffff"

        // 底部分割线
        var bottomLine = View.viewWithFrame(0, 0, width, 0.5)
        bottomLine.bottom = container.height
        bottomLine.backgroundColor = "#d8d8d8"
        container.addSubView(bottomLine)

        var imageView = ImageView.viewWithFrame(paddingLeft, paddingTop, imageWidth, imageWidth)
        imageView.imageUrl = data.frontImg
        imageView.contentMode = 2
        container.addSubView(imageView)

        //满房标签
        var fullRoomContainer = View.viewWithFrame(paddingLeft, paddingTop, imageWidth, imageWidth)
        fullRoomContainer.backgroundColor = "#66000000"
        var fullRoomView = TextView.viewWithFrame(0, 0, 0, 0)
        fullRoomView.textSize = 18
        fullRoomView.textColor = "#FFFFFF"
        if(isFullRoom){
            fullRoomView.text = "满房"
            fullRoomView.sizeToFit()
            fullRoomView.centerX = imageWidth/2
            fullRoomView.centerY = imageWidth/2
        }
        fullRoomView.hidden = !isFullRoom
        fullRoomContainer.hidden = !isFullRoom
        fullRoomContainer.addSubView(fullRoomView)
        container.addSubView(fullRoomContainer)

        //头图大型活动标签
        var topFodderInfoStr = getFodderInfoStr(data, 9003005)
        var topImageView = ImageView.viewWithFrame(paddingLeft, paddingTop + 4, 45, 15)
        topImageView.contentMode = 2
        if(topFodderInfoStr != null && !isFullRoom){
            topImageView.hidden = false
            topImageView.imageUrl = topFodderInfoStr
        } else {
            topImageView.hidden = true
        }
        container.addSubView(topImageView)

        //头图底部标签
        var bottomImageFodderInfoStr = getFodderInfoStr(data, 9003006)
        if(bottomImageFodderInfoStr == null){
            bottomImageFodderInfoStr = getFodderInfoStr(data, 9003004)
        }
        var bottomImageView = ImageView.viewWithFrame(paddingLeft, imageWidth + paddingTop - 15, imageWidth, 15)
        bottomImageView.contentMode = 2
        if(bottomImageFodderInfoStr != null && !isFullRoom){
            bottomImageView.hidden = false
            bottomImageView.imageUrl = bottomImageFodderInfoStr
        } else {
            bottomImageView.hidden = true
        }
        container.addSubView(bottomImageView)

        // 右边的总长度
        var rightWidth = width - paddingLeft * 2 - imageWidth - titlePaddingLeft

        // 第一行，包括酒店名称，HOS标签，广告
        var hosFodderInfoStr = getFodderInfoStr(data, 9003008)
        var hasAds = data.adsInfo != null && data.adsInfo.adType == "3"
        var hosImageView = ImageView.viewWithFrame(0, 0, 0, 0)
        hosImageView.contentMode = 2
        if(hosFodderInfoStr != null && !isFullRoom){
            hosImageView.width = 16
            hosImageView.height = 16
            hosImageView.imageUrl = hosFodderInfoStr
            hosImageView.hidden = false
        } else {
            hosImageView.hidden = true
        }

        var adsTextView = TextView.viewWithFrame(0, 0, 0, 0)
        adsTextView.textColor = getGrayColor(isFullRoom)
        adsTextView.textSize = 12
        adsTextView.textAlignment = 2
        if(hasAds && !isFullRoom){
            adsTextView.text = "广告"
            adsTextView.sizeToFit()
            adsTextView.hidden = false
        } else {
            adsTextView.hidden = true
        }

        var titleView = TextView.viewWithFrame(imageView.right + titlePaddingLeft, imageView.top, 0, 0)
        titleView.text = data.name
        titleView.textSize = 17
        titleView.sizeToFit()
        titleView.numberOfLines = 1
        titleView.lineBreakMode = 4
        titleView.textColor = "#333333"

        if(hosFodderInfoStr != null && hasAds){
            titleWidth = rightWidth - adsTextView.width - hosImageView.width - 10
            if(titleView.width > titleWidth){
                titleView.width = titleWidth
            } else {
                adsTextView.width =  rightWidth - titleView.width - hosImageView.width - 10
            }
            hosImageView.left = titleView.right + 5
            hosImageView.centerY = titleView.centerY
            adsTextView.left = hosImageView.right + 5
            adsTextView.centerY = titleView.centerY
        } else if(hosFodderInfoStr != null){
            titleWidth = rightWidth - hosImageView.width - 5
            if(titleView.width > titleWidth){
                titleView.width = titleWidth
            }
            hosImageView.left = titleView.right + 5
            hosImageView.centerY = titleView.centerY
        } else if(hasAds){
            titleWidth = rightWidth - adsTextView.width - 5
            titleView.width = titleWidth
            adsTextView.left = titleView.right + 5
            adsTextView.centerY = titleView.centerY
        } else {
            titleView.width = rightWidth
        }
        container.addSubView(titleView)
        container.addSubView(hosImageView)
        container.addSubView(adsTextView)

        // 第二行，包括评分，消费人数，星级
        var top = titleView.bottom + 4
        var avgScoreView = TextView.viewWithFrame(titleView.left, top, 0, 0)
        avgScoreView.textSize = 14
        avgScoreView.textColor = getOrangeColor(isFullRoom)
        avgScoreView.text = data.scoreIntro ? data.scoreIntro : ""
        avgScoreView.sizeToFit()
        container.addSubView(avgScoreView)

        var salesView = TextView.viewWithFrame(0, top, 0, avgScoreView.height)
        salesView.textSize = 12
        salesView.textColor = getGrayColor(isFullRoom)
        salesView.left = avgScoreView.right + 5
        salesView.text = data.poiSaleAndSpanTag ? data.poiSaleAndSpanTag : ""
        salesView.sizeToFit()
        salesView.bottom = avgScoreView.bottom
        container.addSubView(salesView)

        hotelStarWidth = rightWidth - avgScoreView.width - salesView.width - 10
        var hotelStarView = TextView.viewWithFrame(0, 0, hotelStarWidth, salesView.height)
        hotelStarView.textSize = 12
        hotelStarView.textColor = getGrayColor(isFullRoom)
        hotelStarView.textAlignment = 2
        if(data.poiRecommendTag){
            hotelStarView.left = salesView.right + 5
            hotelStarView.text = data.poiRecommendTag
            hotelStarView.bottom = salesView.bottom
            hotelStarView.hidden = false
        } else {
            hotelStarView.hidden = true
        }
        container.addSubView(hotelStarView)

        var addressView = TextView.viewWithFrame(titleView.left, avgScoreView.bottom + 3, rightWidth, 0)
        addressView.textColor = getGrayColor(isFullRoom)
        addressView.textSize = 12
        addressView.numberOfLines = 1
        addressView.lineBreakMode = 4
        addressView.text = data.posdescr ? data.posdescr: ""
        addressView.sizeToFit()
        container.addSubView(addressView)

        var top = addressView.bottom + 2
        var priceSuffix = TextView.viewWithFrame(0, top, 0, 0)
        if(hasLowestPrice(data.priceType, data.lowestPrice)) {
            var pricePrefix = TextView.viewWithFrame(titleView.left, top, 0, 0)
            pricePrefix.text = "¥"
            pricePrefix.textSize = 12
            pricePrefix.textColor = getGreenColor(isFullRoom)
            pricePrefix.sizeToFit()

            var priceLabel = TextView.viewWithFrame(0, top, 0, 0)
            priceLabel.left = pricePrefix.right
            priceLabel.text = data.lowestPrice
            priceLabel.textSize = 21
            priceLabel.textColor = getGreenColor(isFullRoom)
            priceLabel.sizeToFit()

            // 模拟基线对齐
            pricePrefix.bottom = priceLabel.bottom - 4;
            container.addSubView(pricePrefix)
            container.addSubView(priceLabel)

            priceSuffix.left = priceLabel.right
            if(typeof(data.kkk)=="undefined") {
              priceSuffix.text = "起"
            } else {
              priceSuffix.text = data.kk
            }
            priceSuffix.textSize = 12
            priceSuffix.textColor = getGreenColor(isFullRoom)
            priceSuffix.sizeToFit()
            priceSuffix.bottom = pricePrefix.bottom;
            container.addSubView(priceSuffix)
        } else {
            priceSuffix.left = titleView.left
            priceSuffix.text = "暂无报价"
            priceSuffix.textSize = 16
            priceSuffix.textColor = "#999999"
            priceSuffix.sizeToFit()
            container.addSubView(priceSuffix)
        }

        //几晚
        var daysSpanTextView = TextView.viewWithFrame(0, 0, 0, 0)
        daysSpanTextView.textSize = 12
        daysSpanTextView.textColor = getGrayColor(isFullRoom)
        daysSpanTextView.left = priceSuffix.right
        if(data.isHourRoom){
            if(data.hourRoomSpan > 0){
                daysSpanTextView.text = "/" + data.hourRoomSpan + "小时"
                daysSpanTextView.hidden = false
            } else {
                daysSpanTextView.hidden = true
            }
        } else {
            if (data.dayRoomSpan > 1){
                daysSpanTextView.text = "/" + data.dayRoomSpan + "晚"
                daysSpanTextView.hidden = false
            } else {
                daysSpanTextView.hidden = true
            }
        }
        daysSpanTextView.sizeToFit()
        daysSpanTextView.bottom = priceSuffix.bottom
        container.addSubView(daysSpanTextView)

        // TODO: 17 is magic number: 需要统一协调右边的padding
        agoWidth = width - daysSpanTextView.right - 17
        var agoLabel = TextView.viewWithFrame(0, 0, 0, 0)
        agoLabel.textAlignment = 2
        agoLabel.textSize = 12
        agoLabel.textColor = getGrayColor(isFullRoom)
        if(data.poiLastOrderTime){
            agoLabel.left = daysSpanTextView.right + 5
            agoLabel.text = data.poiLastOrderTime
            agoLabel.sizeToFit()
            agoLabel.width = agoWidth
            agoLabel.bottom = priceSuffix.bottom
            agoLabel.hidden = false
        } else {
            agoLabel.hidden = true
        }
        container.addSubView(agoLabel)

        // 以下是标签
        var tagContainer = View.viewWithFrame(titleView.left, priceSuffix.bottom + 7, rightWidth, container.height - priceSuffix.bottom + 4)
        tagContainer.left = titleView.left
        var offset = 0
        var isOverWidth = false
        if (data.campaignTagList != null && data.campaignTagList.length > 0){
            for (var i = 0; i < data.campaignTagList.length; i++) {
                var compaingn = data.campaignTagList[i]
                var tagView = createTagLabel(offset, 0, compaingn, "#FF9900", isFullRoom)
                if(offset + tagView.width > rightWidth){
                    isOverWidth = true
                    break
                }
                tagContainer.addSubView(tagView)
                offset += tagView.width + 3;
            }
        }

        if(data.hasPackage && !isOverWidth){
            var tagView = createTagLabel(offset, 0, "套餐", "#FF9900", isFullRoom)
            if(offset + tagView.width > rightWidth){
                isOverWidth = true
            } else {
                tagContainer.addSubView(tagView)
                offset += tagView.width + 3;
            }
        }

        if (data.sourceType > 0 && !isOverWidth) {
            var tagView = createTagLabel(offset, 0, "订", "#F5716E", isFullRoom)
            if(offset + tagView.width > rightWidth){
                isOverWidth = true
            } else {
                tagContainer.addSubView(tagView)
                offset += tagView.width + 3;
            }
        }

        if (data.poiAttrTagList != null && data.poiAttrTagList.length > 0 && !isOverWidth){
            var count = Math.min(2, data.poiAttrTagList.length);//最多显示2个特殊属性标签
            for (var i = 0; i < count; i++) {
                var attrTag = data.poiAttrTagList[i]
                var tagView = createTagLabel(offset, 0, attrTag, "#4AB5F8", isFullRoom)
                if(offset + tagView.width > rightWidth){
                    isOverWidth = true
                    break
                }
                tagContainer.addSubView(tagView)
                offset += tagView.width + 3;
            }
        }
        container.addSubView(tagContainer)

        // 为了测试页面是否展示成功
        var detectFlagView = View.viewWithFrame(0,0,1,1)
        detectFlagView.alpha = 0.0001
        detectFlagView.tag = "123123123123"
        container.addSubView(detectFlagView)
        return container
    }
    HotelCell.layout = layout;
})(HotelCell || (HotelCell = {}));
